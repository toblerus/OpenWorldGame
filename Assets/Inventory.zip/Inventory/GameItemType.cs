﻿namespace Inventory
{
    public enum GameItemType
    {
        Wood = 1,
        Rock = 2,
        Plastic = 3,
        Scrap =4,
    }
}